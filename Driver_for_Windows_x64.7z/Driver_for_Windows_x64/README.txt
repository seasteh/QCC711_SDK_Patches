The latest CH347 driver installer for windows OS:
https://www.wch-ic.com/downloads/CH341PAR_EXE.html

1. Download and Run the installer
2. Click the help button (A prompt box will pop up. Just close it. )
3. Check the checkbox appeared "!! Delete driver when deleting device“
4. Click the uninstall button (A prompt box pops up indicating that the driver has been uninstalled)
5. Click on the installation button (a prompt box pops up indicating that the driver installation is complete)

Other reference for CH347:
https://www.wch-ic.com/downloads/CH347DS1_PDF.html
https://www.wch-ic.com/downloads/CH347EVT_ZIP.html


